package com.example.bff

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class BffApplicationTests {

	@Test
	fun contextLoads() {
	}

}
